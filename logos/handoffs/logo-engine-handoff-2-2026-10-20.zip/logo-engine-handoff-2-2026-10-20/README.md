# Logo engine handoff 2 (2026-10-20)

Lens of Truth's logo, made with the shared logo engine in the Minuet of Forest repo. Each folder is a separate handoff for that project's own Claude Code session, with its own `HANDOFF.md`.

| Folder | For |
|---|---|
| `lens-of-truth/` | Lens of Truth: logo, Windows icon, PNGs and web icons, with directions for wherever the project shows an icon |
| `ice-cavern/` | Ice Cavern: Lens of Truth's door logo, added to the project doors |
